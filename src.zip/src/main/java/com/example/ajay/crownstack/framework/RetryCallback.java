package com.example.ajay.crownstack.framework;

/**
 * Created by Ajay Vyas(Android Developer)
 * on 25/06/18 at SSI(Gurgaon).
 */

public interface RetryCallback {
    void onRetry();
    void onError();
}
